package appointment;

import java.util.Date;

/**
 * Represents an Appointment object in the system.
 * 
 * This class enforces validation rules defined in the project requirements:
 * - appointmentId must be non-null and no longer than 10 characters.
 * - appointmentDate must be non-null and cannot be in the past.
 * - description must be non-null and no longer than 50 characters.
 * 
 * The appointmentId field is immutable once set.
 */
public class Appointment {

    // Unique identifier (cannot be updated after construction)
    private final String appointmentId;

    // Appointment date (must not be in the past)
    private Date appointmentDate;

    // Description of the appointment (max 50 characters)
    private String description;

    /**
     * Constructs an Appointment object with validation.
     *
     * @param appointmentId Unique ID (<= 10 characters, non-null)
     * @param appointmentDate Date of appointment (non-null, not in past)
     * @param description Description (<= 50 characters, non-null)
     * @throws IllegalArgumentException if any validation rule fails
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // Validate appointmentId
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be non-null and <= 10 characters.");
        }

        // Validate appointmentDate
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be non-null and not in the past.");
        }

        // Validate description
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and <= 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    /**
     * Returns the appointment ID.
     *
     * @return appointmentId
     */
    public String getAppointmentId() {
        return appointmentId;
    }

    /**
     * Returns the appointment date.
     *
     * @return appointmentDate
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /**
     * Returns the appointment description.
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Updates the appointment date.
     *
     * @param appointmentDate New date (must not be null or in past)
     * @throws IllegalArgumentException if validation fails
     */
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be non-null and not in the past.");
        }
        this.appointmentDate = appointmentDate;
    }

    /**
     * Updates the appointment description.
     *
     * @param description New description (<= 50 characters, non-null)
     * @throws IllegalArgumentException if validation fails
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and <= 50 characters.");
        }
        this.description = description;
    }
}
