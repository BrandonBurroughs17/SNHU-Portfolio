package contact;

/**
 * Represents a Contact object in the system.
 *
 * Requirements enforced:
 * - contactId must be non-null and <= 10 characters (not updatable)
 * - firstName must be non-null and <= 10 characters
 * - lastName must be non-null and <= 10 characters
 * - phone must be exactly 10 digits (non-null)
 * - address must be non-null and <= 30 characters
 */
public class Contact {

    // Immutable unique identifier
    private final String contactId;

    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructs a Contact object with validation.
     *
     * @param contactId unique ID (<=10 chars, non-null)
     * @param firstName first name (<=10 chars, non-null)
     * @param lastName last name (<=10 chars, non-null)
     * @param phone exactly 10 digits
     * @param address <=30 chars, non-null
     */
    public Contact(String contactId, String firstName,
                   String lastName, String phone, String address) {

        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID.");
        }

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name.");
        }

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name.");
        }

        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
        }

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address.");
        }

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name.");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name.");
        }
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
        }
        this.phone = phone;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address.");
        }
        this.address = address;
    }
}
