package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TaskService.
 *
 * Verifies:
 * - Unique ID enforcement
 * - Add functionality
 * - Delete functionality
 * - Update functionality
 * - Exception handling
 */
public class TaskServiceTest {

    private Task createValidTask(String id) {
        return new Task(id, "Task Name", "Task Description");
    }

    @Test
    void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = createValidTask("T1");

        service.addTask(task);

        assertEquals("T1", service.getTask("T1").getTaskId());
    }

    @Test
    void testAddDuplicateTaskFails() {
        TaskService service = new TaskService();
        Task task = createValidTask("T1");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task);
        });
    }

    @Test
    void testAddNullTaskFails() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        Task task = createValidTask("T1");

        service.addTask(task);
        service.deleteTask("T1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("T1");
        });
    }

    @Test
    void testDeleteNonExistentTaskFails() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("DoesNotExist");
        });
    }

    @Test
    void testUpdateName() {
        TaskService service = new TaskService();
        Task task = createValidTask("T1");

        service.addTask(task);
        service.updateName("T1", "Updated Name");

        assertEquals("Updated Name", service.getTask("T1").getName());
    }

    @Test
    void testUpdateDescription() {
        TaskService service = new TaskService();
        Task task = createValidTask("T1");

        service.addTask(task);
        service.updateDescription("T1", "Updated Description");

        assertEquals("Updated Description", service.getTask("T1").getDescription());
    }

    @Test
    void testUpdateNonExistentTaskFails() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("Invalid", "Name");
        });
    }

    @Test
    void testGetNonExistentTaskFails() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("Invalid");
        });
    }
}
