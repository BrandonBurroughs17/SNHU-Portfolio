package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Contact class.
 *
 * Verifies:
 * - Constructor validation
 * - Field constraints
 * - Setter validation
 */
public class ContactTest {

    private Contact createValidContact() {
        return new Contact("C1", "John", "Doe", "1234567890", "123 Street");
    }

    @Test
    void testValidContactCreation() {
        Contact contact = createValidContact();

        assertEquals("C1", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Street", contact.getAddress());
    }

    @Test
    void testNullIdFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testIdTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "John", "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testNullFirstNameFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", null, "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testFirstNameTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "ThisNameIsTooLong", "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testNullLastNameFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", null, "1234567890", "123 Street"));
    }

    @Test
    void testLastNameTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", "LastNameTooLong", "1234567890", "123 Street"));
    }

    @Test
    void testNullPhoneFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", "Doe", null, "123 Street"));
    }

    @Test
    void testPhoneNotTenDigitsFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", "Doe", "12345", "123 Street"));
    }

    @Test
    void testNullAddressFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", "Doe", "1234567890", null));
    }

    @Test
    void testAddressTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("C1", "John", "Doe", "1234567890",
                        "This address is definitely longer than thirty characters"));
    }

    @Test
    void testSetValidFirstName() {
        Contact contact = createValidContact();
        contact.setFirstName("Jane");

        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    void testSetInvalidPhoneFails() {
        Contact contact = createValidContact();

        assertThrows(IllegalArgumentException.class, () ->
                contact.setPhone("123"));
    }
}
