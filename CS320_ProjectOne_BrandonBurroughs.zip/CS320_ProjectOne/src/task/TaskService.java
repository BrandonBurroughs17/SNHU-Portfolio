package task;

import java.util.HashMap;

/**
 * Service class responsible for managing Task objects.
 *
 * This service stores tasks in memory using a HashMap.
 * No database or UI is used per project requirements.
 *
 * Responsibilities:
 * - Add tasks (must have unique ID)
 * - Delete tasks by ID
 * - Update task name and description by ID
 */
public class TaskService {

    // In-memory storage using taskId as key
    private final HashMap<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new task to the system.
     *
     * @param task Task object to add
     * @throws IllegalArgumentException if task is null
     *                                  or ID already exists
     */
    public void addTask(Task task) {

        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }

        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task by taskId.
     *
     * @param taskId ID of task to delete
     * @throws IllegalArgumentException if task does not exist
     */
    public void deleteTask(String taskId) {

        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found.");
        }

        tasks.remove(taskId);
    }

    /**
     * Updates the name of a task.
     */
    public void updateName(String taskId, String name) {
        getTask(taskId).setName(name);
    }

    /**
     * Updates the description of a task.
     */
    public void updateDescription(String taskId, String description) {
        getTask(taskId).setDescription(description);
    }

    /**
     * Retrieves a task by ID.
     *
     * Helpful for testing and validation.
     *
     * @param taskId ID of task
     * @return Task object
     * @throws IllegalArgumentException if task does not exist
     */
    public Task getTask(String taskId) {

        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found.");
        }

        return tasks.get(taskId);
    }
}
