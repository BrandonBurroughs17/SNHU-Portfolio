package appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

/**
 * Unit tests for AppointmentService.
 * 
 * Verifies:
 * - Unique ID enforcement
 * - Add functionality
 * - Delete functionality
 * - Retrieval functionality
 * - Exception handling for invalid operations
 */
public class AppointmentServiceTest {

    /**
     * Helper method to create a valid future date.
     */
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 1000000);
    }

    @Test
    void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("A1", getFutureDate(), "Doctor Visit");

        service.addAppointment(appointment);

        assertEquals("A1", service.getAppointment("A1").getAppointmentId());
    }

    @Test
    void testAddDuplicateAppointmentFails() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("A1", getFutureDate(), "Doctor Visit");

        service.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("A1", getFutureDate(), "Doctor Visit");

        service.addAppointment(appointment);
        service.deleteAppointment("A1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("A1");
        });
    }

    @Test
    void testDeleteNonExistentAppointmentFails() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("DoesNotExist");
        });
    }

    @Test
    void testGetNonExistentAppointmentFails() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("InvalidID");
        });
    }

    @Test
    void testAddNullAppointmentFails() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }
}
