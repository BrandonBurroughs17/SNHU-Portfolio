package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Task class.
 *
 * Verifies:
 * - Constructor validation
 * - Field constraints
 * - Setter validation
 */
public class TaskTest {

    private Task createValidTask() {
        return new Task("T1", "Valid Name", "Valid Description");
    }

    @Test
    void testValidTaskCreation() {
        Task task = createValidTask();

        assertEquals("T1", task.getTaskId());
        assertEquals("Valid Name", task.getName());
        assertEquals("Valid Description", task.getDescription());
    }

    @Test
    void testNullIdFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Name", "Description"));
    }

    @Test
    void testIdTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testNullNameFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", null, "Description"));
    }

    @Test
    void testNameTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1",
                        "ThisNameIsDefinitelyLongerThanTwentyCharacters",
                        "Description"));
    }

    @Test
    void testNullDescriptionFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "Name", null));
    }

    @Test
    void testDescriptionTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1",
                        "Name",
                        "This description is definitely longer than fifty characters and should fail."));
    }

    @Test
    void testSetValidName() {
        Task task = createValidTask();
        task.setName("Updated Name");

        assertEquals("Updated Name", task.getName());
    }

    @Test
    void testSetInvalidNameFails() {
        Task task = createValidTask();

        assertThrows(IllegalArgumentException.class, () ->
                task.setName("ThisNameIsDefinitelyLongerThanTwentyCharacters"));
    }

    @Test
    void testSetValidDescription() {
        Task task = createValidTask();
        task.setDescription("Updated Description");

        assertEquals("Updated Description", task.getDescription());
    }

    @Test
    void testSetInvalidDescriptionFails() {
        Task task = createValidTask();

        assertThrows(IllegalArgumentException.class, () ->
                task.setDescription(
                        "This description is definitely longer than fifty characters and should fail."));
    }
}
