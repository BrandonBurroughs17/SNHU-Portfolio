package contact;

import java.util.HashMap;

/**
 * Service class responsible for managing Contact objects.
 *
 * This service stores contacts in memory using a HashMap.
 * No database or UI is used per project requirements.
 *
 * Responsibilities:
 * - Add contacts (must have unique ID)
 * - Delete contacts by ID
 * - Update contact fields by ID
 */
public class ContactService {

    // In-memory storage of contacts using contactId as key
    private final HashMap<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the system.
     *
     * @param contact Contact object to add
     * @throws IllegalArgumentException if contact is null
     *                                  or ID already exists
     */
    public void addContact(Contact contact) {

        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }

        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }

        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Deletes a contact by contactId.
     *
     * @param contactId ID of contact to delete
     * @throws IllegalArgumentException if contact does not exist
     */
    public void deleteContact(String contactId) {

        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found.");
        }

        contacts.remove(contactId);
    }

    /**
     * Updates the first name of a contact.
     */
    public void updateFirstName(String contactId, String firstName) {
        getContact(contactId).setFirstName(firstName);
    }

    /**
     * Updates the last name of a contact.
     */
    public void updateLastName(String contactId, String lastName) {
        getContact(contactId).setLastName(lastName);
    }

    /**
     * Updates the phone number of a contact.
     */
    public void updatePhone(String contactId, String phone) {
        getContact(contactId).setPhone(phone);
    }

    /**
     * Updates the address of a contact.
     */
    public void updateAddress(String contactId, String address) {
        getContact(contactId).setAddress(address);
    }

    /**
     * Retrieves a contact by ID.
     *
     * This helper method ensures consistent validation
     * and is useful for unit testing.
     *
     * @param contactId ID of contact
     * @return Contact object
     * @throws IllegalArgumentException if contact does not exist
     */
    public Contact getContact(String contactId) {

        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found.");
        }

        return contacts.get(contactId);
    }
}
