from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # CREATE
    def create(self, data):
        try:
            if data:
                self.collection.insert_one(data)
                return True
            return False
        except Exception as e:
            print("Create Error:", e)
            return False

    # READ
    def read(self, query):
        try:
            if query is not None:
                return list(self.collection.find(query))
            return []
        except Exception as e:
            print("Read Error:", e)
            return []

    # UPDATE
    def update(self, query, new_values):
        try:
            if query and new_values:
                result = self.collection.update_many(query, new_values)
                return result.modified_count
            return 0
        except Exception as e:
            print("Update Error:", e)
            return 0

    # DELETE
    def delete(self, query):
        try:
            if query:
                result = self.collection.delete_many(query)
                return result.deleted_count
            return 0
        except Exception as e:
            print("Delete Error:", e)
            return 0