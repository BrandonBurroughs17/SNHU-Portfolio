package appointment;

import java.util.HashMap;

/**
 * Service class responsible for managing Appointment objects.
 * 
 * This service stores appointments in memory using a HashMap.
 * No database or UI is used per project requirements.
 * 
 * Responsibilities:
 * - Add appointments (must have unique ID)
 * - Delete appointments by ID
 */
public class AppointmentService {

    // In-memory storage of appointments using appointmentId as key
    private final HashMap<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new appointment to the system.
     *
     * @param appointment The Appointment object to add
     * @throws IllegalArgumentException if appointment ID already exists
     */
    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Deletes an appointment by ID.
     *
     * @param appointmentId The ID of the appointment to delete
     * @throws IllegalArgumentException if appointment does not exist
     */
    public void deleteAppointment(String appointmentId) {

        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment not found.");
        }

        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an appointment by ID.
     * 
     * This is helpful for testing and validation.
     *
     * @param appointmentId The appointment ID
     * @return Appointment object
     * @throws IllegalArgumentException if appointment does not exist
     */
    public Appointment getAppointment(String appointmentId) {

        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment not found.");
        }

        return appointments.get(appointmentId);
    }
}
