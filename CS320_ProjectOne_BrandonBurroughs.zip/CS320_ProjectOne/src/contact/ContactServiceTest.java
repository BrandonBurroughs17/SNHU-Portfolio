package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ContactService.
 *
 * Verifies:
 * - Unique ID enforcement
 * - Add functionality
 * - Delete functionality
 * - Update functionality
 * - Exception handling
 */
public class ContactServiceTest {

    private Contact createValidContact(String id) {
        return new Contact(id, "John", "Doe", "1234567890", "123 Street");
    }

    @Test
    void testAddContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);

        assertEquals("C1", service.getContact("C1").getContactId());
    }

    @Test
    void testAddDuplicateContactFails() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact);
        });
    }

    @Test
    void testAddNullContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    @Test
    void testDeleteContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);
        service.deleteContact("C1");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("C1");
        });
    }

    @Test
    void testDeleteNonExistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("DoesNotExist");
        });
    }

    @Test
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);
        service.updateFirstName("C1", "Jane");

        assertEquals("Jane", service.getContact("C1").getFirstName());
    }

    @Test
    void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);
        service.updateLastName("C1", "Smith");

        assertEquals("Smith", service.getContact("C1").getLastName());
    }

    @Test
    void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);
        service.updatePhone("C1", "0987654321");

        assertEquals("0987654321", service.getContact("C1").getPhone());
    }

    @Test
    void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = createValidContact("C1");

        service.addContact(contact);
        service.updateAddress("C1", "456 Avenue");

        assertEquals("456 Avenue", service.getContact("C1").getAddress());
    }

    @Test
    void testUpdateNonExistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("Invalid", "Test");
        });
    }
}
