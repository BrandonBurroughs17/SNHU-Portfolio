package task;

/**
 * Represents a Task object in the system.
 *
 * Requirements enforced:
 * - taskId must be non-null and <= 10 characters (not updatable)
 * - name must be non-null and <= 20 characters
 * - description must be non-null and <= 50 characters
 */
public class Task {

    // Immutable unique identifier
    private final String taskId;

    private String name;
    private String description;

    /**
     * Constructs a Task object with validation.
     *
     * @param taskId unique ID (<=10 chars, non-null)
     * @param name task name (<=20 chars, non-null)
     * @param description task description (<=50 chars, non-null)
     */
    public Task(String taskId, String name, String description) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID.");
        }

        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name.");
        }

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description.");
        }
        this.description = description;
    }
}
