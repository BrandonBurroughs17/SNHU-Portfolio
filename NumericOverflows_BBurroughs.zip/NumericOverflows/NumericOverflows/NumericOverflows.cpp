// NumericOverflows.cpp : This file contains the 'main' function.
// Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid

/// <summary>
/// Safely calculates:
///     start + (increment * steps)
///
/// Returns true if the calculation succeeds.
/// Returns false if an overflow or underflow would occur.
/// The calculated value is stored in result.
/// </summary>
template <typename T>
bool add_numbers(
    T const& start,
    T const& increment,
    unsigned long int const& steps,
    T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        /*
         * Before performing the addition, verify that the next value
         * will remain inside the valid range for type T.
         *
         * Positive increment:
         * result must not be greater than max - increment.
         *
         * Negative increment:
         * result must not be less than lowest - increment.
         */
        if (increment > 0 &&
            result > std::numeric_limits<T>::max() - increment)
        {
            return false;
        }

        if (increment < 0 &&
            result < std::numeric_limits<T>::lowest() - increment)
        {
            return false;
        }

        result += increment;
    }

    return true;
}

/// <summary>
/// Safely calculates:
///     start - (decrement * steps)
///
/// Returns true if the calculation succeeds.
/// Returns false if an overflow or underflow would occur.
/// The calculated value is stored in result.
/// </summary>
template <typename T>
bool subtract_numbers(
    T const& start,
    T const& decrement,
    unsigned long int const& steps,
    T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check before subtracting to determine whether the next
        // operation would cause the result to fall below zero.
        // This prevents the underflow condition expected by the
        // provided test cases.
        if (decrement > result)
        {
            return false;
        }

        result -= decrement;
    }

    return true;
}


// NOTE:
// The unary ('+') operator is used in front of variables in the test methods.
// This forces cout to display smaller character types as numeric values.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};

    std::cout << "\tAdding Numbers Without Overflow ("
        << +start << ", "
        << +increment << ", "
        << steps << ") = ";

    bool success = add_numbers<T>(start, increment, steps, result);

    std::cout << "Overflow Status: " << std::boolalpha << !success;

    if (success)
    {
        std::cout << ", Result: " << +result;
    }
    else
    {
        std::cout << ", Result: calculation prevented";
    }

    std::cout << std::endl;


    std::cout << "\tAdding Numbers With Overflow ("
        << +start << ", "
        << +increment << ", "
        << (steps + 1) << ") = ";

    success = add_numbers<T>(start, increment, steps + 1, result);

    std::cout << "Overflow Status: " << std::boolalpha << !success;

    if (success)
    {
        std::cout << ", Result: " << +result;
    }
    else
    {
        std::cout << ", Result: calculation prevented";
    }

    std::cout << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    // how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};

    std::cout << "\tSubtracting Numbers Without Overflow ("
        << +start << ", "
        << +decrement << ", "
        << steps << ") = ";

    bool success = subtract_numbers<T>(start, decrement, steps, result);

    std::cout << "Underflow Status: " << std::boolalpha << !success;

    if (success)
    {
        std::cout << ", Result: " << +result;
    }
    else
    {
        std::cout << ", Result: calculation prevented";
    }

    std::cout << std::endl;


    std::cout << "\tSubtracting Numbers With Overflow ("
        << +start << ", "
        << +decrement << ", "
        << (steps + 1) << ") = ";

    success = subtract_numbers<T>(start, decrement, steps + 1, result);

    std::cout << "Underflow Status: " << std::boolalpha << !success;

    if (success)
    {
        std::cout << ", Result: " << +result;
    }
    else
    {
        std::cout << ", Result: calculation prevented";
    }

    std::cout << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);

    do_underflow_tests(star_line);

    std::cout << std::endl
        << "All Numeric Underflow / Overflow Tests Complete!"
        << std::endl;

    return 0;
}