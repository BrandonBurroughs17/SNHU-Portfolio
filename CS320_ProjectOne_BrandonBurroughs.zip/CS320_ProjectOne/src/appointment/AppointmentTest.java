package appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

/**
 * Unit tests for Appointment class.
 * 
 * Verifies:
 * - Constructor validation
 * - Field constraints
 * - Setter validation
 */
public class AppointmentTest {

    /**
     * Helper method to generate a valid future date.
     */
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 1000000);
    }

    /**
     * Helper method to generate a past date.
     */
    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 1000000);
    }

    @Test
    void testValidAppointmentCreation() {
        Appointment appointment =
                new Appointment("A1", getFutureDate(), "Valid Description");

        assertEquals("A1", appointment.getAppointmentId());
        assertEquals("Valid Description", appointment.getDescription());
    }

    @Test
    void testNullIdFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, getFutureDate(), "Desc"));
    }

    @Test
    void testIdTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", getFutureDate(), "Desc"));
    }

    @Test
    void testNullDateFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", null, "Desc"));
    }

    @Test
    void testPastDateFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", getPastDate(), "Desc"));
    }

    @Test
    void testNullDescriptionFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", getFutureDate(), null));
    }

    @Test
    void testDescriptionTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("A1", getFutureDate(),
                        "This description is definitely longer than fifty characters and should fail."));
    }

    @Test
    void testSetValidDate() {
        Appointment appointment =
                new Appointment("A1", getFutureDate(), "Desc");

        Date newDate = new Date(System.currentTimeMillis() + 2000000);
        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    void testSetPastDateFails() {
        Appointment appointment =
                new Appointment("A1", getFutureDate(), "Desc");

        assertThrows(IllegalArgumentException.class, () ->
                appointment.setAppointmentDate(getPastDate()));
    }

    @Test
    void testSetValidDescription() {
        Appointment appointment =
                new Appointment("A1", getFutureDate(), "Desc");

        appointment.setDescription("Updated Description");

        assertEquals("Updated Description", appointment.getDescription());
    }

    @Test
    void testSetDescriptionTooLongFails() {
        Appointment appointment =
                new Appointment("A1", getFutureDate(), "Desc");

        assertThrows(IllegalArgumentException.class, () ->
                appointment.setDescription(
                        "This description is definitely longer than fifty characters and should fail."));
    }
}
